using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class Form1 : Form
    {
        private int gridSize = 3; // Default grid size (3x3)
        private Button[,] buttons;
        private bool isPlayerOneTurn = true; // True -> Player X, False -> Player O
        private int turnCount = 0;

        public Form1()
        {
            InitializeComponent();
            InitializeGame();
        }

        private void InitializeGame()
        {
            // Form temizli�i
            this.Controls.Clear();

            // Boyut se�imi i�in ComboBox ekleniyor
            ComboBox gridSizeSelector = new ComboBox
            {
                Location = new Point(10, 10),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Width = 100
            };
            gridSizeSelector.Items.AddRange(new object[] { "3x3", "4x4", "5x5" });
            gridSizeSelector.SelectedIndex = 0; // Varsay�lan 3x3
            gridSizeSelector.SelectedIndexChanged += (s, e) =>
            {
                string selectedSize = gridSizeSelector.SelectedItem.ToString();
                gridSize = int.Parse(selectedSize.Substring(0, 1));
                InitializeGame();
            };
            this.Controls.Add(gridSizeSelector);

            // Dinamik buton matrisi olu�turuluyor
            buttons = new Button[gridSize, gridSize];
            int buttonSize = 400 / gridSize; // D��melerin boyutu (dinamik)

            for (int row = 0; row < gridSize; row++)
            {
                for (int col = 0; col < gridSize; col++)
                {
                    Button button = new Button
                    {
                        Width = buttonSize,
                        Height = buttonSize,
                        Location = new Point(10 + col * buttonSize, 50 + row * buttonSize),
                        Font = new Font(FontFamily.GenericSansSerif, 16),
                        Tag = new Point(row, col)
                    };
                    button.Click += ButtonClick;
                    buttons[row, col] = button;
                    this.Controls.Add(button);
                }
            }

            // S�f�rla butonu ekleniyor
            Button resetButton = new Button
            {
                Text = "Reset",
                Location = new Point(10, 60 + gridSize * buttonSize),
                Width = 100,
                Height = 30
            };
            resetButton.Click += (s, e) => InitializeGame();
            this.Controls.Add(resetButton);

            isPlayerOneTurn = true;
            turnCount = 0;
        }

        private void ButtonClick(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;
            Point position = (Point)clickedButton.Tag;

            clickedButton.Text = isPlayerOneTurn ? "X" : "O";
            clickedButton.Enabled = false;

            turnCount++;
            if (CheckForWinner(position))
            {
                string winner = isPlayerOneTurn ? "Player X" : "Player O";
                MessageBox.Show($"{winner} wins!", "Game Over");
                InitializeGame();
                return;
            }

            if (turnCount == gridSize * gridSize)
            {
                MessageBox.Show("It's a draw!", "Game Over");
                InitializeGame();
                return;
            }

            isPlayerOneTurn = !isPlayerOneTurn;
        }

        private bool CheckForWinner(Point lastMove)
        {
            int row = lastMove.X;
            int col = lastMove.Y;
            string symbol = buttons[row, col].Text;

            // Sat�r kontrol�
            if (Enumerable.Range(0, gridSize).All(c => buttons[row, c].Text == symbol))
                return true;

            // S�tun kontrol�
            if (Enumerable.Range(0, gridSize).All(r => buttons[r, col].Text == symbol))
                return true;

            // Ana �apraz kontrol�
            if (row == col && Enumerable.Range(0, gridSize).All(i => buttons[i, i].Text == symbol))
                return true;

            // Ters �apraz kontrol�
            if (row + col == gridSize - 1 && Enumerable.Range(0, gridSize).All(i => buttons[i, gridSize - 1 - i].Text == symbol))
                return true;

            return false;
        }
    }
}
